Виконала команда: Царук (КМ-03), Орленко(КМ-03), Комінко(КМ-03)

#Інструкція

Для запуску виконати наступну команду

```bach
docker-compose build --no-cache && docker-compose up -d --force-recreate
```
