db_main_host: str = "db"
db_main_port: int = 5432
db_main_name: str = "zno_data"
db_main_user: str = "dreamTeam"
db_main_password: str = "dreamTeam"
